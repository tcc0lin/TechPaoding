package com.lateautumn4lin.cattle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import pl.com.salsoft.sqlitestudioremote.SQLiteStudioService;

/**
 * The type Main activity.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        切换到sqlite activity
        startSQLiteCattleActivity();
//        启动sqlite studio服务
        SQLiteStudioService.instance().start(this);
    }

    private void startSQLiteCattleActivity() {
        Logger.logi("start sqlite cattle activity");
//        Intent intent = new Intent(MainActivity.this, SQLiteCattleActivity.class);
        Intent intent = new Intent(MainActivity.this, SQLcipherCattleActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        Logger.logi("start sqlite cattle activity success");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SQLiteStudioService.instance().stop();
    }
}
